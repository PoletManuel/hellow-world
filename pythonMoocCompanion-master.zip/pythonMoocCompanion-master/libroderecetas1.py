CONST = "constante1 en modulo1 del paquete"
VAR_2 = ",datos adicionales en var"
