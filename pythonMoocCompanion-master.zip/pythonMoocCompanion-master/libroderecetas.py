# -*- coding: utf-8 -*-

GRAVEDAD = 9.8

def miSuma (a,b):
  return a+b